<!-- Footer -->
<?php
// Use the same base path from header
if (!isset($base_path)) {
    $current_dir = dirname($_SERVER['PHP_SELF']);
    if (strpos($current_dir, 'result-checker') !== false || strpos($current_dir, 'admin') !== false) {
        $base_path = '../';
    } else {
        $base_path = '';
    }
}

// ── Fetch contact settings from DB (same pattern as contact.php) ──────────────
if (!function_exists('getSetting')) {
    function getSetting($conn, $key, $default = '') {
        $r = $conn->query("SELECT setting_value FROM school_settings WHERE setting_key='".mysqli_real_escape_string($conn,$key)."' LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        return $row ? $row['setting_value'] : $default;
    }
}

// $conn is expected to be available (set in header.php / config/database.php)
$footer_phone   = isset($conn) ? getSetting($conn, 'school_phone',   '09125128213') : '09125128213';
$footer_email   = isset($conn) ? getSetting($conn, 'school_email',   'golaedu2026@gmail.com') : 'golaedu2026@gmail.com';
$footer_address = isset($conn) ? getSetting($conn, 'school_address', 'Ntezi, Ishielu LGA, Ebonyi State, Nigeria') : 'Ntezi, Ishielu LGA, Ebonyi State, Nigeria';
$footer_name    = isset($conn) ? getSetting($conn, 'school_name',    'Goodness Omogo Leadership Academy') : 'Goodness Omogo Leadership Academy';
$footer_tagline = isset($conn) ? getSetting($conn, 'school_tagline',  'To Learn • To Grow • To Lead') : 'To Learn • To Grow • To Lead';
?>
<footer class="bg-primary text-white mt-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            <!-- School Info -->
            <div>
                <div class="flex items-center gap-3 mb-6">
                    <img src="<?php echo $base_path; ?>asset/favicon.png" 
                         alt="Logo" 
                         class="h-12 w-auto">
                </div>
                <p class="text-slate-300 text-sm leading-relaxed mb-4">
                    Excellence in leadership and academics. Preparing tomorrow's leaders. Empowering students to excel globally and serve locally.
                </p>
                <p class="text-gold font-display italic text-sm">
                    "<?php echo htmlspecialchars($footer_tagline); ?>"
                </p>
            </div>
            
            <!-- Quick Links -->
            <div>
                <h3 class="text-gold font-semibold text-lg mb-4 uppercase tracking-wider">Quick Links</h3>
                <ul class="space-y-3 text-sm">
                    <li><a href="<?php echo $base_path; ?>about.php" class="hover:text-gold transition-colors">About Us</a></li>
                    <li><a href="<?php echo $base_path; ?>academics.php" class="hover:text-gold transition-colors">Academics</a></li>
                    <li><a href="<?php echo $base_path; ?>admissions.php" class="hover:text-gold transition-colors">Admissions</a></li>
                    <li><a href="<?php echo $base_path; ?>news.php" class="hover:text-gold transition-colors">News & Events</a></li>
                    <li><a href="<?php echo $base_path; ?>contact.php" class="hover:text-gold transition-colors">Contact Us</a></li>
                    <li><a href="<?php echo $base_path; ?>result-checker/" class="hover:text-gold transition-colors">Result Checker</a></li>
                </ul>
            </div>
            
            <!-- For Students & Parents -->
            <div>
                <h3 class="text-gold font-semibold text-lg mb-4 uppercase tracking-wider">Resources</h3>
                <ul class="space-y-3 text-sm">
                    <li><a href="<?php echo $base_path; ?>result-checker/" class="hover:text-gold transition-colors">Check Results</a></li>
                    
                    <li><a href="<?php echo $base_path; ?>admin/login.php" class="hover:text-gold transition-colors">Teacher Portal</a></li>
                    <li><a href="#" class="hover:text-gold transition-colors">Career Opportunities</a></li>
                    <li><a href="#" class="hover:text-gold transition-colors">School Fees & Finance</a></li>
                    <li><a href="#" class="hover:text-gold transition-colors">Student Handbook</a></li>
                    <li><a href="#" class="hover:text-gold transition-colors">Alumni Network</a></li>
                </ul>
            </div>
            
            <!-- Contact Info -->
            <div>
                <h3 class="text-gold font-semibold text-lg mb-4 uppercase tracking-wider">Contact Us</h3>
                <ul class="space-y-4 text-sm">
                    <li class="flex items-start gap-3">
                        <span class="material-symbols-outlined text-gold mt-0.5">location_on</span>
                        <span class="text-slate-300"><?php echo htmlspecialchars($footer_address); ?></span>
                    </li>
                    <li class="flex items-center gap-3">
                        <span class="material-symbols-outlined text-gold">phone</span>
                        <a href="tel:<?php echo preg_replace('/\s+/', '', $footer_phone); ?>" class="text-slate-300 hover:text-gold transition-colors"><?php echo htmlspecialchars($footer_phone); ?></a>
                    </li>
                    <li class="flex items-center gap-3">
                        <span class="material-symbols-outlined text-gold">mail</span>
                        <a href="mailto:<?php echo htmlspecialchars($footer_email); ?>" class="text-slate-300 hover:text-gold transition-colors"><?php echo htmlspecialchars($footer_email); ?></a>
                    </li>
                </ul>
                
                <!-- Social Media -->
                <div class="mt-6">
                    <h4 class="text-gold font-semibold text-sm mb-3 uppercase tracking-wider">Follow Our Story</h4>
                    <div class="flex gap-3">
                        <a href="#" class="bg-white/10 hover:bg-gold hover:text-primary p-2.5 rounded transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"/>
                            </svg>
                        </a>
                        <a href="#" class="bg-white/10 hover:bg-gold hover:text-primary p-2.5 rounded transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path fill-rule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clip-rule="evenodd"/>
                            </svg>
                        </a>
                        <a href="#" class="bg-white/10 hover:bg-gold hover:text-primary p-2.5 rounded transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path fill-rule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clip-rule="evenodd"/>
                            </svg>
                        </a>
                        <a href="#" class="bg-white/10 hover:bg-gold hover:text-primary p-2.5 rounded transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path fill-rule="evenodd" d="M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.746 22 12 22 12s0 3.255-.418 4.814a2.504 2.504 0 0 1-1.768 1.768c-1.56.419-7.814.419-7.814.419s-6.255 0-7.814-.419a2.505 2.505 0 0 1-1.768-1.768C2 15.255 2 12 2 12s0-3.255.417-4.814a2.507 2.507 0 0 1 1.768-1.768C5.744 5 11.998 5 11.998 5s6.255 0 7.814.418ZM15.194 12 10 15V9l5.194 3Z" clip-rule="evenodd"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bottom Bar -->
        <div class="border-t border-slate-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p class="text-slate-400 text-sm text-center md:text-left">
                © <?php echo date('Y'); ?> <?php echo htmlspecialchars($footer_name); ?>. All rights reserved. 
                <span class="hidden md:inline">Powered by Academic Excellence</span>
            </p>
            <div class="flex gap-6 text-sm text-slate-400">
                <a href="#" class="hover:text-gold transition-colors">Privacy Policy</a>
                <a href="#" class="hover:text-gold transition-colors">Terms of Service</a>
                <a href="#" class="hover:text-gold transition-colors">Sitemap</a>
            </div>
        </div>
    </div>
</footer>

</body>
</html>