<?php 
$page_title = "Result Checker";
include '../includes/header.php'; 
?>

<!-- Result Checker Hero Section -->
<section class="py-16 bg-gradient-to-br from-primary to-slate-800 text-white">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div class="inline-flex items-center gap-2 px-4 py-2 bg-gold/20 border border-gold/30 rounded-full text-gold font-semibold text-sm uppercase tracking-widest mb-6">
            <span class="material-symbols-outlined">school</span>
            Student Results Portal
        </div>
        <h1 class="text-4xl lg:text-6xl font-display font-black mb-4">Check Your Results</h1>
        <p class="text-xl text-slate-300">Enter your student ID to view your academic performance</p>
    </div>
</section>

<!-- Result Checker Form -->
<section class="py-16 bg-slate-50 dark:bg-slate-900">
    <div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl p-8 lg:p-12">
            <div class="text-center mb-8">
                <div class="inline-block p-4 bg-gold/10 rounded-full mb-4">
                    <span class="material-symbols-outlined text-5xl text-gold">assignment</span>
                </div>
                <h2 class="text-3xl font-display font-bold text-primary dark:text-gold mb-2">Enter Your Details</h2>
                <p class="text-slate-600 dark:text-slate-400">Your Student ID can be found on your ID card</p>
            </div>
            
            <form id="resultCheckerForm" action="view-result.php" method="POST" class="space-y-6">
                <!-- Student ID -->
                <div>
                    <label for="student_id" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Student ID <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-slate-400">badge</span>
                        <input 
                            type="text" 
                            id="student_id" 
                            name="student_id" 
                            required 
                            placeholder="e.g., GOLA/2024/001"
                            class="w-full pl-12 pr-4 py-4 border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-gold focus:ring-2 focus:ring-gold/20 dark:bg-slate-700 dark:text-white transition-all"
                        >
                    </div>
                    <p class="mt-2 text-xs text-slate-500 dark:text-slate-400">Format: GOLA/YYYY/XXX</p>
                </div>
                
                <!-- Academic Session -->
                <div>
                    <label for="session_id" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Academic Session <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-slate-400">calendar_today</span>
                        <select 
                            id="session_id" 
                            name="session_id" 
                            required
                            class="w-full pl-12 pr-4 py-4 border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-gold focus:ring-2 focus:ring-gold/20 dark:bg-slate-700 dark:text-white transition-all appearance-none bg-no-repeat"
                            style="background-image: url('data:image/svg+xml;charset=UTF-8,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27currentColor%27 stroke-width=%272%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27%3e%3cpolyline points=%276 9 12 15 18 9%27%3e%3c/polyline%3e%3c/svg%3e'); background-position: right 1rem center; background-size: 1.5em 1.5em;"
                        >
                            <option value="">Select Session</option>
                            <option value="1">2024/2025</option>
                            <option value="2">2023/2024</option>
                        </select>
                    </div>
                </div>
                
                <!-- Term -->
                <div>
                    <label for="term_id" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Term <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-slate-400">event_note</span>
                        <select 
                            id="term_id" 
                            name="term_id" 
                            required
                            class="w-full pl-12 pr-4 py-4 border-2 border-slate-200 dark:border-slate-700 rounded-xl focus:border-gold focus:ring-2 focus:ring-gold/20 dark:bg-slate-700 dark:text-white transition-all appearance-none"
                            style="background-image: url('data:image/svg+xml;charset=UTF-8,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27currentColor%27 stroke-width=%272%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27%3e%3cpolyline points=%276 9 12 15 18 9%27%3e%3c/polyline%3e%3c/svg%3e'); background-position: right 1rem center; background-size: 1.5em 1.5em;"
                        >
                            <option value="">Select Term</option>
                            <option value="1">First Term</option>
                            <option value="2">Second Term</option>
                            <option value="3">Third Term</option>
                        </select>
                    </div>
                </div>
                
                <!-- Submit Button -->
                <button 
                    type="submit" 
                    class="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 px-6 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                    <span class="material-symbols-outlined">search</span>
                    Check My Result
                </button>
            </form>
            
            <!-- Help Text -->
            <div class="mt-8 p-4 bg-gold/10 border border-gold/20 rounded-xl">
                <div class="flex gap-3">
                    <span class="material-symbols-outlined text-gold flex-shrink-0">info</span>
                    <div class="text-sm">
                        <p class="font-semibold text-primary dark:text-gold mb-1">Need Help?</p>
                        <p class="text-slate-600 dark:text-slate-400">If you've forgotten your Student ID or having trouble accessing your results, please contact the school office at <a href="tel:+2348012345678" class="text-gold hover:underline">+234 800 123 4567</a> or email <a href="mailto:results@goodnessomogo.edu.ng" class="text-gold hover:underline">results@goodnessomogo.edu.ng</a></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Additional Information -->
        <div class="mt-8 grid md:grid-cols-3 gap-6">
            <div class="text-center p-6 bg-white dark:bg-slate-800 rounded-xl shadow-lg">
                <div class="inline-block p-3 bg-gold/10 rounded-full mb-3">
                    <span class="material-symbols-outlined text-3xl text-gold">verified</span>
                </div>
                <h3 class="font-bold text-primary dark:text-gold mb-2">Secure Access</h3>
                <p class="text-sm text-slate-600 dark:text-slate-400">Your results are protected and only accessible with your Student ID</p>
            </div>
            
            <div class="text-center p-6 bg-white dark:bg-slate-800 rounded-xl shadow-lg">
                <div class="inline-block p-3 bg-gold/10 rounded-full mb-3">
                    <span class="material-symbols-outlined text-3xl text-gold">schedule</span>
                </div>
                <h3 class="font-bold text-primary dark:text-gold mb-2">24/7 Availability</h3>
                <p class="text-sm text-slate-600 dark:text-slate-400">Check your results anytime, anywhere, from any device</p>
            </div>
            
            <div class="text-center p-6 bg-white dark:bg-slate-800 rounded-xl shadow-lg">
                <div class="inline-block p-3 bg-gold/10 rounded-full mb-3">
                    <span class="material-symbols-outlined text-3xl text-gold">print</span>
                </div>
                <h3 class="font-bold text-primary dark:text-gold mb-2">Print Ready</h3>
                <p class="text-sm text-slate-600 dark:text-slate-400">Download and print your result sheet for your records</p>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
