<?php
require_once '../config/database.php';

// Function to calculate grade
function calculateGrade($score) {
    global $conn;
    $stmt = $conn->prepare("SELECT grade, remark FROM grading_system WHERE ? BETWEEN min_score AND max_score");
    $stmt->bind_param("d", $score);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row;
    }
    return ['grade' => 'F9', 'remark' => 'Fail'];
}

$error = null;
$student = null;
$results = [];
$summary = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = trim($_POST['student_id']);
    $session_id = intval($_POST['session_id']);
    $term_id = intval($_POST['term_id']);
    
    // Fetch student information
    $stmt = $conn->prepare("
        SELECT s.*, c.class_name, c.arm 
        FROM students s 
        JOIN classes c ON s.class_id = c.id 
        WHERE s.student_id = ? AND s.status = 'Active'
    ");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    
    if (!$student) {
        $error = "Student ID not found or inactive. Please check your Student ID and try again.";
    } else {
        // Fetch results
        $stmt = $conn->prepare("
            SELECT r.*, sub.subject_name, sub.subject_code
            FROM results r
            JOIN subjects sub ON r.subject_id = sub.id
            WHERE r.student_id = ? AND r.session_id = ? AND r.term_id = ?
            ORDER BY sub.subject_name
        ");
        $stmt->bind_param("iii", $student['id'], $session_id, $term_id);
        $stmt->execute();
        $result_data = $stmt->get_result();
        
        if ($result_data->num_rows == 0) {
            $error = "No results found for the selected session and term. Results may not have been published yet.";
        } else {
            while ($row = $result_data->fetch_assoc()) {
                $results[] = $row;
            }
            
            // Fetch or calculate summary
            $stmt = $conn->prepare("
                SELECT * FROM result_summary 
                WHERE student_id = ? AND session_id = ? AND term_id = ?
            ");
            $stmt->bind_param("iii", $student['id'], $session_id, $term_id);
            $stmt->execute();
            $summary_result = $stmt->get_result();
            $summary = $summary_result->fetch_assoc();
            
            if (!$summary) {
                // Calculate summary if not exists
                $total_score = 0;
                $total_subjects = count($results);
                foreach ($results as $r) {
                    $total_score += $r['total_score'];
                }
                $average = $total_subjects > 0 ? $total_score / $total_subjects : 0;
                
                $summary = [
                    'total_subjects' => $total_subjects,
                    'total_score' => $total_score,
                    'average_score' => $average,
                    'overall_position' => null,
                    'class_teacher_comment' => 'Keep up the good work!',
                    'principal_comment' => 'Excellent performance.',
                    'published' => true
                ];
            }
        }
        
        // Fetch session and term details
        $stmt = $conn->prepare("SELECT session_name FROM academic_sessions WHERE id = ?");
        $stmt->bind_param("i", $session_id);
        $stmt->execute();
        $session_result = $stmt->get_result();
        $session_info = $session_result->fetch_assoc();
        
        $stmt = $conn->prepare("SELECT term_name FROM terms WHERE id = ?");
        $stmt->bind_param("i", $term_id);
        $stmt->execute();
        $term_result = $stmt->get_result();
        $term_info = $term_result->fetch_assoc();
    }
}

if ($error || !$student) {
    $page_title = "Result Not Found";
    include '../includes/header.php';
    ?>
    
    <section class="py-16 min-h-screen bg-slate-50 dark:bg-slate-900">
        <div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8 text-center">
                <div class="inline-block p-4 bg-red-100 dark:bg-red-900/20 rounded-full mb-4">
                    <span class="material-symbols-outlined text-5xl text-red-500">error</span>
                </div>
                <h2 class="text-2xl font-bold text-primary dark:text-gold mb-4">Result Not Found</h2>
                <p class="text-slate-600 dark:text-slate-400 mb-6"><?php echo htmlspecialchars($error ?? 'Please try again.'); ?></p>
                <a href="index.php" class="inline-flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-lg hover:bg-opacity-90 transition-all">
                    <span class="material-symbols-outlined">arrow_back</span>
                    Go Back
                </a>
            </div>
        </div>
    </section>
    
    <?php
    include '../includes/footer.php';
    exit;
}

$page_title = "Student Result - " . $student['first_name'] . " " . $student['last_name'];
include '../includes/header.php';
?>

<!-- Result Sheet -->
<section class="py-8 bg-slate-50 dark:bg-slate-900 print:bg-white">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Print Button -->
        <div class="mb-6 flex justify-between items-center print:hidden">
            <a href="index.php" class="inline-flex items-center gap-2 text-primary dark:text-gold hover:underline">
                <span class="material-symbols-outlined">arrow_back</span>
                Back to Result Checker
            </a>
            <button onclick="window.print()" class="inline-flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-lg hover:bg-opacity-90 transition-all">
                <span class="material-symbols-outlined">print</span>
                Print Result
            </button>
        </div>
        
        <!-- Result Card -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl overflow-hidden print:shadow-none">
            <!-- Header Section -->
            <div class="bg-gradient-to-r from-primary to-slate-800 text-white p-8 text-center relative overflow-hidden">
                <div class="absolute inset-0 opacity-10">
                    <div class="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-gold via-transparent to-transparent"></div>
                </div>
                <div class="relative z-10">
                    <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuC6ceWaKZGDHZ8nrAUvBxK-fPVHeYCvnW3Lan_6q9pWdG9n1EOnufK6x-pLdJ3NHoApMrcS3KqnDsgfGMhKxpsCnVAJvIZYzWuDHvl4r1jX_BLkzqTGknt8X1G8QT2mWB2t7OwX_BEuJP7zyx4oqcfjUTPpPYrkRfV45OhRB3wQNYjq7rr0rkYaK1moBtPcAlHoiUKNKtm5VSpHFUwu1DclPpMO61uKdATXu9JKD2d64Lp-yDpmUnAaqNS_sUPKFfJOE2UuNcvmG3P_" 
                         alt="Logo" 
                         class="h-20 w-auto mx-auto mb-4">
                    <h1 class="text-3xl font-display font-black mb-2">GOODNESS OMOGO LEADERSHIP ACADEMY</h1>
                    <p class="text-slate-300">Excellence in Education, Character & Leadership</p>
                    <div class="mt-4 inline-block px-4 py-2 bg-gold/20 border border-gold/30 rounded-full text-gold font-semibold">
                        STUDENT TERMINAL RESULT REPORT
                    </div>
                </div>
            </div>
            
            <!-- Student Information -->
            <div class="p-8 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-700">
                <div class="grid md:grid-cols-2 gap-6">
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-slate-600 dark:text-slate-400 font-semibold">Student Name:</span>
                            <span class="text-primary dark:text-gold font-bold"><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name'] . ' ' . $student['other_name']); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-600 dark:text-slate-400 font-semibold">Student ID:</span>
                            <span class="text-primary dark:text-gold font-bold"><?php echo htmlspecialchars($student['student_id']); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-600 dark:text-slate-400 font-semibold">Class:</span>
                            <span class="text-primary dark:text-gold font-bold"><?php echo htmlspecialchars($student['class_name'] . ' ' . $student['arm']); ?></span>
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-slate-600 dark:text-slate-400 font-semibold">Session:</span>
                            <span class="text-primary dark:text-gold font-bold"><?php echo htmlspecialchars($session_info['session_name']); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-600 dark:text-slate-400 font-semibold">Term:</span>
                            <span class="text-primary dark:text-gold font-bold"><?php echo htmlspecialchars($term_info['term_name']); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-600 dark:text-slate-400 font-semibold">No. of Subjects:</span>
                            <span class="text-primary dark:text-gold font-bold"><?php echo $summary['total_subjects']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Results Table -->
            <div class="p-8">
                <h2 class="text-2xl font-bold text-primary dark:text-gold mb-6 flex items-center gap-2">
                    <span class="material-symbols-outlined">assignment</span>
                    Subject Performance
                </h2>
                
                <div class="overflow-x-auto">
                    <table class="w-full border-collapse">
                        <thead>
                            <tr class="bg-primary text-white">
                                <th class="px-4 py-3 text-left text-sm font-semibold border border-slate-300">S/N</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold border border-slate-300">Subject</th>
                                <th class="px-4 py-3 text-center text-sm font-semibold border border-slate-300">CA1<br>(10)</th>
                                <th class="px-4 py-3 text-center text-sm font-semibold border border-slate-300">CA2<br>(10)</th>
                                <th class="px-4 py-3 text-center text-sm font-semibold border border-slate-300">CA3<br>(10)</th>
                                <th class="px-4 py-3 text-center text-sm font-semibold border border-slate-300">Exam<br>(70)</th>
                                <th class="px-4 py-3 text-center text-sm font-semibold border border-slate-300">Total<br>(100)</th>
                                <th class="px-4 py-3 text-center text-sm font-semibold border border-slate-300">Grade</th>
                                <th class="px-4 py-3 text-center text-sm font-semibold border border-slate-300">Remark</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sn = 1;
                            foreach ($results as $result) {
                                $grade_info = calculateGrade($result['total_score']);
                                $grade_class = '';
                                if (str_starts_with($grade_info['grade'], 'A')) $grade_class = 'text-green-600';
                                elseif (str_starts_with($grade_info['grade'], 'B')) $grade_class = 'text-blue-600';
                                elseif (str_starts_with($grade_info['grade'], 'C')) $grade_class = 'text-yellow-600';
                                elseif (str_starts_with($grade_info['grade'], 'D')) $grade_class = 'text-orange-600';
                                else $grade_class = 'text-red-600';
                                
                                echo '<tr class="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600">' . $sn++ . '</td>';
                                echo '<td class="px-4 py-3 border border-slate-300 dark:border-slate-600 font-semibold">' . htmlspecialchars($result['subject_name']) . '</td>';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600">' . number_format($result['ca1'], 1) . '</td>';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600">' . number_format($result['ca2'], 1) . '</td>';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600">' . number_format($result['ca3'], 1) . '</td>';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600">' . number_format($result['exam_score'], 1) . '</td>';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600 font-bold text-lg">' . number_format($result['total_score'], 1) . '</td>';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600 font-bold ' . $grade_class . '">' . htmlspecialchars($grade_info['grade']) . '</td>';
                                echo '<td class="px-4 py-3 text-center border border-slate-300 dark:border-slate-600 text-sm">' . htmlspecialchars($grade_info['remark']) . '</td>';
                                echo '</tr>';
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr class="bg-gold text-primary font-bold">
                                <td colspan="6" class="px-4 py-3 text-right border border-slate-300">TOTAL SCORE:</td>
                                <td class="px-4 py-3 text-center border border-slate-300 text-lg"><?php echo number_format($summary['total_score'], 1); ?></td>
                                <td colspan="2" class="px-4 py-3 border border-slate-300"></td>
                            </tr>
                            <tr class="bg-primary text-white font-bold">
                                <td colspan="6" class="px-4 py-3 text-right border border-slate-300">AVERAGE SCORE:</td>
                                <td class="px-4 py-3 text-center border border-slate-300 text-lg"><?php echo number_format($summary['average_score'], 2); ?>%</td>
                                <td colspan="2" class="px-4 py-3 border border-slate-300"></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            
            <!-- Grading System -->
            <div class="p-8 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700">
                <h3 class="text-lg font-bold text-primary dark:text-gold mb-4">Grading System</h3>
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-9 gap-2 text-xs">
                    <?php
                    $grades_stmt = $conn->query("SELECT * FROM grading_system ORDER BY min_score DESC");
                    while ($grade = $grades_stmt->fetch_assoc()) {
                        echo '<div class="text-center p-2 bg-white dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">';
                        echo '<div class="font-bold text-primary dark:text-gold">' . htmlspecialchars($grade['grade']) . '</div>';
                        echo '<div class="text-slate-600 dark:text-slate-400">' . $grade['min_score'] . '-' . $grade['max_score'] . '</div>';
                        echo '<div class="text-slate-500 text-xs">' . htmlspecialchars($grade['remark']) . '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
            
            <!-- Comments Section -->
            <div class="p-8 border-t border-slate-200 dark:border-slate-700">
                <div class="space-y-6">
                    <?php if (!empty($summary['class_teacher_comment'])): ?>
                    <div>
                        <h3 class="font-bold text-primary dark:text-gold mb-2 flex items-center gap-2">
                            <span class="material-symbols-outlined">comment</span>
                            Class Teacher's Comment
                        </h3>
                        <p class="text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg">
                            <?php echo htmlspecialchars($summary['class_teacher_comment']); ?>
                        </p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($summary['principal_comment'])): ?>
                    <div>
                        <h3 class="font-bold text-primary dark:text-gold mb-2 flex items-center gap-2">
                            <span class="material-symbols-outlined">comment</span>
                            Principal's Comment
                        </h3>
                        <p class="text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg">
                            <?php echo htmlspecialchars($summary['principal_comment']); ?>
                        </p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Footer Info -->
            <div class="p-6 bg-primary text-white text-center text-sm">
                <p>This result is computer-generated and valid without signature.</p>
                <p class="mt-2 text-slate-300">Generated on: <?php echo date('l, F j, Y \a\t g:i A'); ?></p>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
