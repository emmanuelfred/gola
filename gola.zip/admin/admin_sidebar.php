<!-- Admin Sidebar Component -->
<aside class="w-64 bg-primary text-white flex-shrink-0 overflow-y-auto">
    <!-- Logo -->
    <div class="p-6 border-b border-white/10">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                <span class="material-symbols-outlined text-primary">school</span>
            </div>
            <div>
                <h1 class="font-bold text-sm">G.O.L.A.</h1>
                <p class="text-xs text-slate-300">ADMIN PORTAL</p>
            </div>
        </div>
    </div>
    
    <!-- Navigation -->
    <nav class="p-4 space-y-6">
        
        <!-- Dashboard -->
        <div>
            <a href="dashboard.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                <span class="material-symbols-outlined text-xl">dashboard</span>
                <span class="font-medium">Overview</span>
            </a>
        </div>
        
        <!-- Management Section -->
        <div>
            <p class="px-4 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Management</p>
            <div class="space-y-1">
                <a href="manage_students.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_students.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">group</span>
                    <span class="font-medium">Students</span>
                </a>
                <a href="manage_staff.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_staff.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">badge</span>
                    <span class="font-medium">Staff Records</span>
                </a>
                <a href="manage_classes.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_classes.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">class</span>
                    <span class="font-medium">Classes</span>
                </a>
            </div>
        </div>
        
        <!-- Academics Section -->
        <div>
            <p class="px-4 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Academics</p>
            <div class="space-y-1">
                <a href="manage_results.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_results.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">assignment</span>
                    <span class="font-medium">Results</span>
                </a>
                <a href="manage_subjects.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_subjects.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">menu_book</span>
                    <span class="font-medium">Subjects</span>
                </a>
                <a href="timetables.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'timetables.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">calendar_month</span>
                    <span class="font-medium">Timetables</span>
                </a>
            </div>
        </div>
        
        <!-- News & Content Section -->
        <div>
            <p class="px-4 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Content</p>
            <div class="space-y-1">
                <a href="manage-news.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage-news.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">newspaper</span>
                    <span class="font-medium">News Articles</span>
                </a>
                <a href="add-news.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'add-news.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">add_circle</span>
                    <span class="font-medium">Add News</span>
                </a>
                <a href="manage-gallery.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage-gallery.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">photo_library</span>
                    <span class="font-medium">Gallery Images</span>
                </a>
                <a href="add-gallery-image.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'add-gallery-image.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">add_photo_alternate</span>
                    <span class="font-medium">Upload Image</span>
                </a>
            </div>
        </div>
        
        <!-- Academics Section -->
        <div>
            <p class="px-4 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Academics</p>
            <div class="space-y-1">
                <a href="manage-events.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage-events.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">event</span>
                    <span class="font-medium">Academic Events</span>
                </a>
                <a href="add-event.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'add-event.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">event_available</span>
                    <span class="font-medium">Add Event</span>
                </a>
                <a href="manage-subjects.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage-subjects.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">menu_book</span>
                    <span class="font-medium">Subjects</span>
                </a>
                <a href="manage-departments.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage-departments.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">school</span>
                    <span class="font-medium">Departments</span>
                </a>
            </div>
        </div>
        
        <!-- System -->
        <div>
            <p class="px-4 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">System</p>
            <div class="space-y-1">
                <a href="settings.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?> flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all">
                    <span class="material-symbols-outlined text-xl">settings</span>
                    <span class="font-medium">Settings</span>
                </a>
            </div>
        </div>
        
    </nav>
</aside>
