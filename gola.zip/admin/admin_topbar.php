<!-- Admin Top Bar Component -->
<header class="bg-white border-b border-slate-200 px-8 py-4">
    <div class="flex justify-between items-center">
        <div class="flex-1 max-w-xl">
            <div class="relative">
                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">search</span>
                <input 
                    type="search" 
                    placeholder="Search students, staff or records..."
                    class="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold/20 focus:border-gold"
                >
            </div>
        </div>
        
        <div class="flex items-center gap-4">
            <button class="relative p-2 hover:bg-slate-50 rounded-lg transition-all">
                <span class="material-symbols-outlined text-slate-600">notifications</span>
                <span class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            
            <div class="flex items-center gap-3 pl-4 border-l border-slate-200">
                <div class="text-right">
                    <p class="text-sm font-semibold text-slate-900"><?php echo htmlspecialchars($admin_name); ?></p>
                    <p class="text-xs text-slate-500 capitalize"><?php echo htmlspecialchars(str_replace('_', ' ', $admin_role)); ?></p>
                </div>
                <div class="w-10 h-10 bg-gold rounded-full flex items-center justify-center text-primary font-bold">
                    <?php echo strtoupper(substr($admin_name, 0, 2)); ?>
                </div>
            </div>
            
            <a href="logout.php" class="ml-2 p-2 text-red-600 hover:bg-red-50 rounded-lg transition-all" title="Logout">
                <span class="material-symbols-outlined">logout</span>
            </a>
        </div>
    </div>
</header>
